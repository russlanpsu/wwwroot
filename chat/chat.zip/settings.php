<?php
$hostName = 'localhost';
$userName = 'root';
$password = 'pass_word';
$dbName = 'dev_schema';
?>